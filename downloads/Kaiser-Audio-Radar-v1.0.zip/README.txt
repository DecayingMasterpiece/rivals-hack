================================================================================
KAISER AUDIO RADAR v1.0 — THE EQUALIZER
Universal Stereo Direction Visualizer for Roblox Rivals
================================================================================

100% UNBANNABLE · ACCESSIBILITY SOUND VISUALIZER · ZERO ROBLOX INJECTION

This software levels the playing field against closet cheaters by analyzing
stereo loopback audio coming from your computer's sound card and visualizing
which direction footsteps and gunshots are coming from.

Roblox's Hyperion anti-cheat CANNOT ban you for using this:
- Zero DLL injection
- Zero memory modification
- Zero game file tampering
- 100% External: Uses the exact same principle as Fortnite's Visual Audio Wheel.

--------------------------------------------------------------------------------
HOW TO RUN ON WINDOWS:
--------------------------------------------------------------------------------
1. Double-click "Run_Windows.bat" in this folder.
2. Select Option 1 (Windows App) or Option 2 (Universal Python Engine).
3. Select your headphones/speakers from the dropdown.
4. Hit "Start Capture" and enter your match!

- Toggle Crosshair HUD: Check "Crosshair HUD" (or press Home)
- Toggle Mini Radar: Check "Mini Radar" (or press End)

--------------------------------------------------------------------------------
HOW TO RUN ON MAC:
--------------------------------------------------------------------------------
1. Open the "universal-radar" folder.
2. Double-click "Run_Mac.command" (or run "python3 kaiser_audio_radar.py" in terminal).
3. Enjoy full crosshair and radar overlays!

--------------------------------------------------------------------------------
STAND WITH THE RIVALS RESISTANCE:
Subscribe to Kaiser: https://www.youtube.com/@KaiserEverhart-Adaptation
Discord Community: https://discord.com/invite/vRu6bYdTWF
================================================================================
