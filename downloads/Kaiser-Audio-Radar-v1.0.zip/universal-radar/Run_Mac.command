#!/bin/bash
# ================================================================
#  KAISER AUDIO RADAR - UNIVERSAL SOUND DIRECTION VISUALIZER
#  macOS Double-Clickable Launcher with Auto-Dependency Installer
# ================================================================

cd "$(dirname "$0")" || exit 1

echo "================================================================"
echo "   KAISER AUDIO RADAR - UNIVERSAL SOUND DIRECTION VISUALIZER"
echo "   macOS Accessibility Audio Indicator (Intel & Apple Silicon)"
echo "================================================================"
echo ""

# 1. Check Python 3
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed."
    echo "Please install Python from https://www.python.org/ or via Homebrew: brew install python"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

# 2. Check and auto-install dependencies
echo "[*] Checking audio dependencies..."
if ! python3 -c "import sounddevice, numpy" &> /dev/null; then
    echo "[*] Installing missing audio libraries (sounddevice, numpy)..."
    python3 -m pip install --upgrade pip > /dev/null 2>&1
    python3 -m pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to install dependencies via pip."
        read -p "Press Enter to exit..."
        exit 1
    fi
    echo "[✓] Dependencies installed successfully!"
else
    echo "[✓] All audio dependencies verified!"
fi

echo ""
echo "[*] Starting Kaiser Audio Radar..."
echo "[*] Mode: Universal Audio Direction Visualizer"
echo ""

python3 kaiser_audio_radar.py
