@echo off
setlocal
cd /d "%~dp0"
title Kaiser Audio Radar - Universal Sound Direction Visualizer

echo ================================================================
echo    KAISER AUDIO RADAR - UNIVERSAL SOUND DIRECTION VISUALIZER
echo    100%% Legal Accessibility Audio Indicator (Windows and Mac)
echo ================================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    echo Check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo [*] Checking audio dependencies...
python -c "import pyaudiowpatch, numpy" >nul 2>nul
if errorlevel 1 (
    echo [*] Installing missing audio libraries (pyaudiowpatch, numpy)...
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed successfully!
) else (
    echo [OK] All audio dependencies verified!
)

echo.
echo [*] Starting Kaiser Audio Radar...
echo [*] Mode: Universal System Audio Loopback (Speakers / Headphones)
echo.

python kaiser_audio_radar.py
if errorlevel 1 (
    echo.
    echo [!] Program exited with error.
    pause
)
