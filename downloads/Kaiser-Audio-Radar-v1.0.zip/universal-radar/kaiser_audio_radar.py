"""
===================================================================
 KAISER AUDIO RADAR — UNIVERSAL SOUND DIRECTION VISUALIZER
===================================================================
 100% Legal Accessibility Audio Visualizer for Windows and macOS.
 Visualizes stereo loudness (Left vs. Right) in real-time.
 ZERO window targeting, ZERO process hooking, ZERO memory injection.
 Operates purely on audio output signals from the sound card.
===================================================================
"""

import sys
import os
import time
import math
import threading
import platform
from dataclasses import dataclass
from typing import Optional, List, Tuple

import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np

# Cross-platform audio loopback / input libraries
IS_WINDOWS = sys.platform == "win32"
IS_MACOS = sys.platform == "darwin"

USE_PYAUDIO = False
try:
    if IS_WINDOWS:
        import pyaudiowpatch as pyaudio
        USE_PYAUDIO = True
    else:
        import sounddevice as sd
except ImportError:
    try:
        import sounddevice as sd
    except ImportError:
        print("[!] Audio libraries missing. Run Run_Windows.bat or Run_Mac.command.")
        sys.exit(1)

if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes


# -----------------------------------------------------------------
# Data Models & Cue Representation
# -----------------------------------------------------------------
@dataclass
class SoundCue:
    direction: str   # "LEFT", "RIGHT", "CENTER"
    pan: float       # -1.0 (Far Left) to +1.0 (Far Right)
    intensity: float # 0.0 to 1.0
    confidence: float
    timestamp: float


# -----------------------------------------------------------------
# Real-Time Audio DSP & Direction Analyzer
# -----------------------------------------------------------------
class AudioCueAnalyzer:
    """
    Computes real-time stereo loudness, pan balance, and transient onsets.
    Pinpoints if Left or Right channel is louder with smooth visual decay.
    """
    def __init__(self, sample_rate: int = 48000):
        self.sample_rate = sample_rate
        self.noise_floor = 0.0001
        self.previous_rms = 0.0
        self.sensitivity = 1.0
        self.calibrating = False
        self.calibration_until = 0.0
        self.activity_level = 0.0
        self.smoothed_pan = 0.0
        self.last_cue: Optional[SoundCue] = None
        self.last_cue_time = 0.0
        self.calibration_samples: List[float] = []

    def start_calibration(self, duration_sec: float = 3.0):
        self.calibrating = True
        self.calibration_until = time.time() + duration_sec
        self.calibration_samples.clear()

    def process_frame(self, pcm: np.ndarray) -> Optional[SoundCue]:
        now = time.time()
        channels = pcm.shape[1] if pcm.ndim > 1 else 1

        if channels < 2:
            return None

        # Calculate RMS energy per channel
        left_ch = pcm[:, 0].astype(np.float32)
        right_ch = pcm[:, 1].astype(np.float32)

        left_energy = float(np.mean(left_ch ** 2))
        right_energy = float(np.mean(right_ch ** 2))

        left_rms = math.sqrt(max(left_energy, 1e-12))
        right_rms = math.sqrt(max(right_energy, 1e-12))
        total_rms = math.sqrt(max((left_energy + right_energy) / 2.0, 1e-12))

        # Handle quiet room calibration
        if self.calibrating:
            self.calibration_samples.append(total_rms)
            if now >= self.calibration_until:
                self.calibrating = False
                if self.calibration_samples:
                    avg_noise = float(np.mean(self.calibration_samples))
                    self.noise_floor = max(0.00002, min(avg_noise * 1.1, 0.0015))
            return None

        # Adaptive ambient tracking (clamp tightly so noise floor NEVER deafens the detector)
        if total_rms < self.noise_floor * 1.6:
            self.noise_floor = 0.992 * self.noise_floor + 0.008 * total_rms
        elif total_rms < self.noise_floor:
            self.noise_floor = total_rms
        # Capped to 0.002 max so long gameplay never causes detection loss
        self.noise_floor = max(0.000015, min(self.noise_floor, 0.002))

        # Activity level (0.0 to 1.0)
        ratio = total_rms / max(self.noise_floor, 1e-6)
        self.activity_level = float(np.clip(math.log2(1.0 + ratio) / 6.0, 0.0, 1.0))

        # Instantaneous Stereo Panning Balance: -1.0 (Left) to +1.0 (Right)
        pan = (right_rms - left_rms) / max(right_rms + left_rms, 1e-9)

        # Smooth pan to stabilize direction while keeping transient response fast
        alpha = 0.55
        self.smoothed_pan = (1.0 - alpha) * self.smoothed_pan + alpha * pan

        # Minimum audible threshold
        sens = max(0.4, min(self.sensitivity, 2.5))
        min_audible = max(0.00004 / sens, self.noise_floor * 1.12)

        if total_rms < min_audible:
            self.previous_rms = total_rms
            return None

        # Onset Detection: Energy sudden jump relative to previous frame
        prev = max(self.previous_rms, self.noise_floor * 0.75)
        is_onset = (total_rms / max(prev, 1e-6)) > 1.10
        self.previous_rms = total_rms

        # Intensity calculation (0.1 to 1.0)
        intensity = float(np.clip((total_rms - self.noise_floor) / max(self.noise_floor * 8.0, 1e-6), 0.15, 1.0))

        # Direction classification based on which ear is louder
        abs_pan = abs(self.smoothed_pan)
        if abs_pan < 0.10:
            direction = "CENTER"
        elif self.smoothed_pan < 0:
            direction = "LEFT"
        else:
            direction = "RIGHT"

        confidence = float(np.clip(0.35 + 0.65 * abs_pan, 0.25, 1.0))

        # Emit cue on sudden spikes or strong continuous directional panning
        if (is_onset or abs_pan > 0.12) and total_rms > min_audible:
            if now - self.last_cue_time > 0.04:
                self.last_cue_time = now
                cue = SoundCue(
                    direction=direction,
                    pan=self.smoothed_pan,
                    intensity=intensity,
                    confidence=confidence,
                    timestamp=now
                )
                self.last_cue = cue
                return cue

        return None


# -----------------------------------------------------------------
# Bulletproof Universal Audio Stream Manager
# -----------------------------------------------------------------
class AudioStreamManager:
    """
    Captures native audio loopback on Windows (via WASAPI Loopback)
    and default monitor/mic input on macOS.
    Includes auto-reconnect watchdog to ensure continuous operation.
    """
    def __init__(self, analyzer: AudioCueAnalyzer):
        self.analyzer = analyzer
        self.running = False
        self.selected_device_id: Optional[int] = None
        self.device_list: List[dict] = []
        self.default_loopback_index: int = 0
        self.latest_levels = (0.0, 0.0)
        self.last_packet_time = 0.0
        self._pa_instance = None
        self._pa_stream = None
        self._sd_stream = None
        self.active_device_name = "Default System Output"

    def refresh_devices(self) -> List[Tuple[int, str]]:
        self.device_list = []
        result = []
        self.default_loopback_index = 0

        if USE_PYAUDIO:
            try:
                p = pyaudio.PyAudio()
                self._pa_instance = p
                wasapi_info = p.get_host_api_info_by_type(pyaudio.paWASAPI)
                def_out_idx = wasapi_info.get("defaultOutputDevice", -1)
                def_out_name = ""
                if def_out_idx >= 0:
                    def_out_name = p.get_device_info_by_index(def_out_idx).get("name", "")

                # Loopback playback devices (Speakers / Headphones)
                for loop in p.get_loopback_device_info_generator():
                    clean_name = loop["name"].replace(" [Loopback]", "")
                    display_name = f"[Playback] {clean_name}"
                    curr_idx = len(self.device_list)
                    self.device_list.append({
                        "id": loop["index"],
                        "name": display_name,
                        "raw_name": loop["name"],
                        "channels": loop["maxInputChannels"],
                        "rate": int(loop["defaultSampleRate"]),
                        "is_loopback": True
                    })
                    result.append((loop["index"], display_name))

                    if def_out_name and (def_out_name in loop["name"] or loop["name"] in def_out_name):
                        self.default_loopback_index = curr_idx

            except Exception as e:
                print(f"[!] PyAudio device query warning: {e}")
        else:
            # Fallback sounddevice for macOS and generic inputs
            try:
                for idx, dev in enumerate(sd.query_devices()):
                    if dev["max_input_channels"] > 0:
                        name = f"[Audio] {dev['name']}"
                        self.device_list.append({
                            "id": idx,
                            "name": name,
                            "raw_name": dev["name"],
                            "channels": dev["max_input_channels"],
                            "rate": int(dev["default_samplerate"]),
                            "is_loopback": False
                        })
                        result.append((idx, name))
            except Exception as e:
                print(f"[!] SoundDevice device query warning: {e}")

        return result

    def start_stream(self, device_id: Optional[int] = None) -> bool:
        self.stop_stream()

        if USE_PYAUDIO:
            return self._start_pyaudio_stream(device_id)
        else:
            return self._start_sounddevice_stream(device_id)

    def _start_pyaudio_stream(self, device_id: Optional[int]) -> bool:
        try:
            if not self._pa_instance:
                self._pa_instance = pyaudio.PyAudio()
            p = self._pa_instance

            # Target device
            target_dev = None
            if device_id is not None:
                for d in self.device_list:
                    if d["id"] == device_id:
                        target_dev = d
                        break

            if not target_dev and self.device_list:
                target_dev = self.device_list[self.default_loopback_index]

            if not target_dev:
                return False

            dev_id = target_dev["id"]
            dev_channels = target_dev["channels"]
            rate = target_dev["rate"]
            self.active_device_name = target_dev["name"]

            def pa_callback(in_data, frame_count, time_info, status):
                try:
                    samples = np.frombuffer(in_data, dtype=np.float32)
                    ch = dev_channels
                    if ch > 0:
                        rem = len(samples) % ch
                        if rem != 0:
                            samples = samples[:-rem]
                        samples = samples.reshape(-1, ch)

                        if ch == 2:
                            left_sig = samples[:, 0]
                            right_sig = samples[:, 1]
                        elif ch >= 6:
                            # 5.1 / 7.1 surround downmix into left and right ears
                            left_sig = samples[:, 0] + 0.707 * samples[:, 4]
                            if ch >= 8:
                                left_sig = left_sig + 0.707 * samples[:, 6]
                            right_sig = samples[:, 1] + 0.707 * samples[:, 5]
                            if ch >= 8:
                                right_sig = right_sig + 0.707 * samples[:, 7]
                        else:
                            left_sig = samples[:, 0]
                            right_sig = samples[:, min(1, ch - 1)]

                        stereo_pair = np.column_stack((left_sig, right_sig))
                        l = float(np.sqrt(max(np.mean(left_sig ** 2), 1e-12)))
                        r = float(np.sqrt(max(np.mean(right_sig ** 2), 1e-12)))
                        self.latest_levels = (l, r)
                        self.last_packet_time = time.time()
                        self.analyzer.process_frame(stereo_pair)
                except Exception:
                    pass
                return (in_data, pyaudio.paContinue)

            self._pa_stream = p.open(
                format=pyaudio.paFloat32,
                channels=dev_channels,
                rate=rate,
                input=True,
                input_device_index=dev_id,
                frames_per_buffer=1024,
                stream_callback=pa_callback
            )
            self._pa_stream.start_stream()
            self.running = True
            self.selected_device_id = dev_id
            self.last_packet_time = time.time()
            return True
        except Exception as ex:
            print(f"[!] PyAudio loopback stream start error: {ex}")
            return False

    def _start_sounddevice_stream(self, device_id: Optional[int]) -> bool:
        try:
            dev_idx = device_id if device_id is not None else 0
            dev_info = sd.query_devices(dev_idx)
            channels = min(2, dev_info["max_input_channels"])
            sample_rate = int(dev_info.get("default_samplerate", 48000))

            def sd_callback(indata, frames, time_info, status):
                if indata.shape[1] >= 2:
                    l = float(np.sqrt(max(np.mean(indata[:, 0] ** 2), 1e-12)))
                    r = float(np.sqrt(max(np.mean(indata[:, 1] ** 2), 1e-12)))
                    self.latest_levels = (l, r)
                    self.last_packet_time = time.time()
                    self.analyzer.process_frame(indata)

            self._sd_stream = sd.InputStream(
                device=dev_idx,
                channels=channels,
                samplerate=sample_rate,
                blocksize=1024,
                callback=sd_callback
            )
            self._sd_stream.start()
            self.running = True
            self.selected_device_id = dev_idx
            self.last_packet_time = time.time()
            return True
        except Exception as ex:
            print(f"[!] SoundDevice stream start error: {ex}")
            return False

    def check_and_reconnect(self):
        """Watchdog: reconnect stream if Windows audio engine stalled."""
        if self.running and (time.time() - self.last_packet_time > 4.0):
            # Stream appears idle/stalled, attempt seamless restart
            self.start_stream(self.selected_device_id)

    def stop_stream(self):
        self.running = False
        if self._pa_stream:
            try:
                self._pa_stream.stop_stream()
                self._pa_stream.close()
            except Exception:
                pass
            self._pa_stream = None
        if self._sd_stream:
            try:
                self._sd_stream.stop()
                self._sd_stream.close()
            except Exception:
                pass
            self._sd_stream = None


# -----------------------------------------------------------------
# Transparent, Click-Through Overlay (Crosshair HUD & Mini Radar)
# -----------------------------------------------------------------
class RadarOverlayWindow:
    """
    Transparent, click-through overlay window.
    Modes:
      1. Mini Radar (top-right circular compass)
      2. Crosshair HUD (directional brackets around crosshair)
    """
    def __init__(self, root: tk.Tk, analyzer: AudioCueAnalyzer):
        self.root = root
        self.analyzer = analyzer
        self.window = tk.Toplevel(root)
        self.mode = "RADAR"  # "RADAR" or "HUD"
        self.visible = True
        self.scale = 1.0

        # Cue animation decay
        self.active_cue: Optional[SoundCue] = None
        self.cue_alpha = 0.0

        self.setup_window()
        bg_col = "#000001" if IS_WINDOWS else ("systemTransparent" if IS_MACOS else "#000000")
        self.canvas = tk.Canvas(self.window, bg=bg_col, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        if IS_WINDOWS:
            self.make_click_through()

        self.animate_loop()

    def setup_window(self):
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)

        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()

        if self.mode == "RADAR":
            w, h = int(240 * self.scale), int(260 * self.scale)
            x = screen_w - w - 40
            y = 50
            self.window.geometry(f"{w}x{h}+{x}+{y}")
        else:
            self.window.geometry(f"{screen_w}x{screen_h}+0+0")

        if IS_WINDOWS:
            self.window.config(bg="#000001")
            self.window.wm_attributes("-transparentcolor", "#000001")
        elif IS_MACOS:
            self.window.config(bg="systemTransparent")
            self.window.wm_attributes("-alpha", 0.90)

    def make_click_through(self):
        if not IS_WINDOWS:
            return
        try:
            self.window.update_idletasks()
            hwnd = wintypes.HWND(int(self.window.frame(), 16))

            GWL_EXSTYLE = -20
            WS_EX_TRANSPARENT = 0x00000020
            WS_EX_LAYERED = 0x00080000

            GetWindowLong = ctypes.windll.user32.GetWindowLongW
            SetWindowLong = ctypes.windll.user32.SetWindowLongW

            if hwnd:
                style = GetWindowLong(hwnd, GWL_EXSTYLE)
                SetWindowLong(hwnd, GWL_EXSTYLE, style | WS_EX_TRANSPARENT | WS_EX_LAYERED)

            ctypes.windll.user32.SetWindowPos.argtypes = [
                wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint
            ]
            ctypes.windll.user32.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
        except Exception:
            pass

    def set_mode(self, mode: str, scale: float = 1.0):
        self.mode = mode
        self.scale = scale
        self.setup_window()
        if IS_WINDOWS:
            self.make_click_through()

    def toggle_visibility(self):
        self.visible = not self.visible
        if self.visible:
            self.window.deiconify()
        else:
            self.window.withdraw()

    def animate_loop(self):
        if self.visible:
            self.render()
        self.window.after(33, self.animate_loop)

    def render(self):
        self.canvas.delete("all")
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 10 or h < 10:
            return

        now = time.time()
        cue = self.analyzer.last_cue

        if cue and (now - cue.timestamp) < 1.3:
            self.active_cue = cue
            decay = 1.0 - (now - cue.timestamp) / 1.3
            self.cue_alpha = max(0.0, decay)
        else:
            self.cue_alpha = max(0.0, self.cue_alpha - 0.08)

        if self.mode == "RADAR":
            self.render_compact_radar(w, h)
        else:
            self.render_crosshair_hud(w, h)

    def render_compact_radar(self, w: int, h: int):
        cx = w // 2
        cy = (h - 30) // 2
        r = min(cx, cy) - 18

        # Radar Outer Frame
        self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill="#080e18", outline="#00f5ff", width=2)
        self.canvas.create_oval(cx - r * 0.65, cy - r * 0.65, cx + r * 0.65, cy + r * 0.65, outline="#1c3554", width=1)
        self.canvas.create_oval(cx - r * 0.30, cy - r * 0.30, cx + r * 0.30, cy + r * 0.30, outline="#1c3554", width=1)

        # Crosshair lines
        self.canvas.create_line(cx - r, cy, cx + r, cy, fill="#1c3554", width=1)
        self.canvas.create_line(cx, cy - r, cx, cy + r, fill="#1c3554", width=1)

        # Direction labels
        left_hl = "#00f5ff" if (self.active_cue and self.active_cue.direction == "LEFT") else "#647b9e"
        right_hl = "#00f5ff" if (self.active_cue and self.active_cue.direction == "RIGHT") else "#647b9e"
        self.canvas.create_text(cx - r + 15, cy, text="LEFT", fill=left_hl, font=("Segoe UI", 9, "bold"))
        self.canvas.create_text(cx + r - 15, cy, text="RIGHT", fill=right_hl, font=("Segoe UI", 9, "bold"))
        self.canvas.create_text(cx, cy - r + 14, text="AHEAD", fill="#647b9e", font=("Segoe UI", 8, "bold"))

        # Audio activity ring (pulses with live sound volume)
        act = self.analyzer.activity_level
        if act > 0.05:
            pulse_r = r * (0.2 + 0.8 * act)
            self.canvas.create_oval(cx - pulse_r, cy - pulse_r, cx + pulse_r, cy + pulse_r, outline="#00f5ff", width=1)

        # Active directional cue
        if self.active_cue and self.cue_alpha > 0.05:
            pan = self.active_cue.pan
            angle_rad = pan * (math.pi / 2.0) - (math.pi / 2.0)
            target_x = cx + r * 0.82 * math.cos(angle_rad)
            target_y = cy + r * 0.82 * math.sin(angle_rad)

            color = "#00f076" if self.active_cue.direction == "CENTER" else "#ff2e3b"

            # Draw directional blip
            blip_size = 9 + int(self.active_cue.intensity * 6)
            self.canvas.create_oval(
                target_x - blip_size, target_y - blip_size,
                target_x + blip_size, target_y + blip_size,
                fill=color, outline="#ffffff", width=2
            )

            # Directional beam
            self.canvas.create_line(cx, cy, target_x, target_y, fill=color, width=3)

            # Bottom Banner
            pct = int(abs(pan) * 100)
            dir_text = f"◀ {self.active_cue.direction} ({pct}%)" if pan < 0 else f"{self.active_cue.direction} ({pct}%) ▶"
            if self.active_cue.direction == "CENTER":
                dir_text = "▲ BALANCED AHEAD"
            self.canvas.create_text(cx, h - 14, text=dir_text, fill=color, font=("Segoe UI", 9, "bold"))
        else:
            self.canvas.create_text(cx, h - 14, text="● LISTENING STEREO", fill="#00f5ff", font=("Segoe UI", 8))

    def render_crosshair_hud(self, w: int, h: int):
        cx = w // 2
        cy = h // 2
        bracket_dist = 180

        # Subtle resting center crosshair
        self.canvas.create_oval(cx - 24, cy - 24, cx + 24, cy + 24, outline="#3a557c", width=1)
        self.canvas.create_line(cx - 10, cy, cx + 10, cy, fill="#00f5ff", width=1)
        self.canvas.create_line(cx, cy - 10, cx, cy + 10, fill="#00f5ff", width=1)
        self.canvas.create_oval(cx - 2, cy - 2, cx + 2, cy + 2, fill="#00f5ff", outline="")

        # Resting brackets (clean, visible contrast)
        lx = cx - bracket_dist
        rx = cx + bracket_dist
        self.canvas.create_arc(lx - 25, cy - 40, lx + 25, cy + 40, start=135, extent=90, style="arc", outline="#3a557c", width=2)
        self.canvas.create_arc(rx - 25, cy - 40, rx + 25, cy + 40, start=-45, extent=90, style="arc", outline="#3a557c", width=2)

        # Active Directional Flash
        if self.active_cue and self.cue_alpha > 0.05:
            pan = self.active_cue.pan
            color = "#ff2e3b" if self.active_cue.intensity > 0.35 else "#ffd066"

            if pan < -0.10:
                self.canvas.create_arc(lx - 45, cy - 65, lx + 45, cy + 65, start=120, extent=120, style="arc", outline=color, width=6)
                self.canvas.create_text(lx - 75, cy, text="◀ LOUDER LEFT", fill=color, font=("Segoe UI", 14, "bold"))
            elif pan > 0.10:
                self.canvas.create_arc(rx - 45, cy - 65, rx + 45, cy + 65, start=-60, extent=120, style="arc", outline=color, width=6)
                self.canvas.create_text(rx + 75, cy, text="LOUDER RIGHT ▶", fill=color, font=("Segoe UI", 14, "bold"))
            else:
                self.canvas.create_text(cx, cy - 70, text="▲ AHEAD", fill="#00f076", font=("Segoe UI", 12, "bold"))


# -----------------------------------------------------------------
# Clean, Simple & Modern UI (Youth & Gamer Friendly)
# -----------------------------------------------------------------
class KaiserRadarApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Kaiser Audio Radar")
        self.root.geometry("480x520")
        self.root.resizable(False, False)
        self.root.configure(bg="#0c121d")

        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        if os.path.exists(icon_path):
            try:
                self.app_icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, self.app_icon)
            except Exception:
                pass

        self.analyzer = AudioCueAnalyzer()
        self.audio_manager = AudioStreamManager(self.analyzer)
        self.overlay = RadarOverlayWindow(self.root, self.analyzer)

        self.build_ui()
        self.audio_manager.start_stream()
        self.update_meters_loop()

    def build_ui(self):
        # Header banner
        header = tk.Frame(self.root, bg="#0c121d")
        header.pack(fill=tk.X, padx=24, pady=(20, 10))

        title = tk.Label(header, text="KAISER AUDIO RADAR", font=("Segoe UI", 16, "bold"), fg="#00f5ff", bg="#0c121d")
        title.pack(anchor="w")

        subtitle = tk.Label(header, text="Find where the enemy sound is coming from (Left vs. Right)", font=("Segoe UI", 9), fg="#9cb1d6", bg="#0c121d")
        subtitle.pack(anchor="w")

        # Container
        panel = tk.Frame(self.root, bg="#131c2e", bd=1, relief=tk.SOLID)
        panel.pack(fill=tk.BOTH, expand=True, padx=24, pady=10)

        # 1. Audio Playback Device Selector
        lbl_dev = tk.Label(panel, text="SELECT YOUR HEADPHONES / SPEAKERS", font=("Segoe UI", 9, "bold"), fg="#ffd066", bg="#131c2e")
        lbl_dev.pack(anchor="w", padx=20, pady=(16, 6))

        devices = self.audio_manager.refresh_devices()
        dev_names = [d[1] for d in devices] if devices else ["Default Speakers"]

        self.dev_combo = ttk.Combobox(panel, values=dev_names, state="readonly", width=42)
        if dev_names:
            self.dev_combo.current(self.audio_manager.default_loopback_index)
        self.dev_combo.pack(padx=20, pady=(0, 10), fill=tk.X)
        self.dev_combo.bind("<<ComboboxSelected>>", self.on_device_changed)

        # 2. Live Left / Right Volume Meter
        lbl_meters = tk.Label(panel, text="LIVE EAR VOLUME (LEFT vs. RIGHT)", font=("Segoe UI", 9, "bold"), fg="#ffffff", bg="#131c2e")
        lbl_meters.pack(anchor="w", padx=20, pady=(10, 6))

        vu_frame = tk.Frame(panel, bg="#131c2e")
        vu_frame.pack(fill=tk.X, padx=20, pady=4)

        lbl_l = tk.Label(vu_frame, text="L:", font=("Segoe UI", 9, "bold"), fg="#00f5ff", bg="#131c2e")
        lbl_l.grid(row=0, column=0, padx=(0, 6))
        self.bar_left = ttk.Progressbar(vu_frame, orient="horizontal", length=350, mode="determinate")
        self.bar_left.grid(row=0, column=1)

        lbl_r = tk.Label(vu_frame, text="R:", font=("Segoe UI", 9, "bold"), fg="#00f5ff", bg="#131c2e")
        lbl_r.grid(row=1, column=0, padx=(0, 6), pady=(6, 0))
        self.bar_right = ttk.Progressbar(vu_frame, orient="horizontal", length=350, mode="determinate")
        self.bar_right.grid(row=1, column=1, pady=(6, 0))

        # 3. Sound Sensitivity Slider
        lbl_sens = tk.Label(panel, text="HEARING SENSITIVITY (Default: 100%)", font=("Segoe UI", 9, "bold"), fg="#ffffff", bg="#131c2e")
        lbl_sens.pack(anchor="w", padx=20, pady=(16, 4))

        self.sens_slider = tk.Scale(panel, from_=50, to=200, orient=tk.HORIZONTAL, bg="#131c2e", fg="#00f5ff",
                                    highlightthickness=0, troughcolor="#080e18", length=390)
        self.sens_slider.set(100)
        self.sens_slider.pack(padx=20)
        self.sens_slider.config(command=lambda v: setattr(self.analyzer, 'sensitivity', float(v) / 100.0))

        # 4. Mode Switch Buttons
        btn_frame = tk.Frame(panel, bg="#131c2e")
        btn_frame.pack(fill=tk.X, padx=20, pady=16)

        self.btn_toggle_hud = tk.Button(btn_frame, text="🔄 Switch: Crosshair HUD", font=("Segoe UI", 9, "bold"),
                                        bg="#1a2d48", fg="#ffd066", activebackground="#ffd066", activeforeground="#000000",
                                        relief=tk.FLAT, padx=14, pady=8, command=self.on_toggle_mode)
        self.btn_toggle_hud.pack(side=tk.LEFT, padx=(0, 10))

        self.btn_calib = tk.Button(btn_frame, text="🎯 Auto-Quiet Noise (3s)", font=("Segoe UI", 9, "bold"),
                                   bg="#1a2d48", fg="#00f5ff", activebackground="#00f5ff", activeforeground="#000000",
                                   relief=tk.FLAT, padx=12, pady=8, command=self.on_calibrate)
        self.btn_calib.pack(side=tk.LEFT)

        # 5. Status Footer
        bottom_frame = tk.Frame(self.root, bg="#0c121d")
        bottom_frame.pack(fill=tk.X, padx=24, pady=(6, 16))

        self.status_lbl = tk.Label(bottom_frame, text="● Radar Active · Listening to game audio", font=("Segoe UI", 9), fg="#00f076", bg="#0c121d")
        self.status_lbl.pack(side=tk.LEFT)

        self.btn_power = tk.Button(bottom_frame, text="Hide/Show [F8]", font=("Segoe UI", 9, "bold"),
                                   bg="#00f5ff", fg="#000000", relief=tk.FLAT, padx=14, pady=6, command=self.overlay.toggle_visibility)
        self.btn_power.pack(side=tk.RIGHT)

        self.root.bind("<F8>", lambda e: self.overlay.toggle_visibility())

    def on_device_changed(self, event):
        idx = self.dev_combo.current()
        devices = self.audio_manager.device_list
        if 0 <= idx < len(devices):
            dev_id = devices[idx]["id"]
            self.audio_manager.start_stream(dev_id)
            self.status_lbl.config(text=f"● Audio Device: {devices[idx]['name'][:28]}...")

    def on_calibrate(self):
        self.analyzer.start_calibration(3.0)
        self.btn_calib.config(text="Listening ambient...", state=tk.DISABLED)
        self.root.after(3200, lambda: self.btn_calib.config(text="🎯 Auto-Quiet Noise (3s)", state=tk.NORMAL))

    def on_toggle_mode(self):
        if self.overlay.mode == "RADAR":
            self.overlay.set_mode("HUD")
            self.btn_toggle_hud.config(text="🔄 Switch: Mini Radar")
            self.status_lbl.config(text="● Mode: Crosshair HUD Active")
        else:
            self.overlay.set_mode("RADAR")
            self.btn_toggle_hud.config(text="🔄 Switch: Crosshair HUD")
            self.status_lbl.config(text="● Mode: Mini Radar Active")

    def update_meters_loop(self):
        # Check watchdog to ensure continuous capture
        self.audio_manager.check_and_reconnect()

        l_rms, r_rms = self.audio_manager.latest_levels
        l_pct = min(100, int(math.sqrt(l_rms) * 190))
        r_pct = min(100, int(math.sqrt(r_rms) * 190))

        self.bar_left['value'] = l_pct
        self.bar_right['value'] = r_pct

        self.root.after(40, self.update_meters_loop)


def main():
    root = tk.Tk()
    app = KaiserRadarApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
