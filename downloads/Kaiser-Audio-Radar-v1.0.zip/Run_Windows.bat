@echo off
setlocal
cd /d "%~dp0"
title Kaiser Audio Radar - Universal Sound Direction Visualizer

echo ================================================================
echo       KAISER AUDIO RADAR - SOUND DIRECTION VISUALIZER
echo    100%% Safe Accessibility Audio Visualizer (Left vs Right)
echo ================================================================
echo.
echo Select how you want to run Kaiser Radar:
echo.
echo [1] Launch Windows App (Fastest - No Setup Needed) [Default]
echo [2] Launch Universal Python Engine (Auto-Installs Dependencies)
echo.
set /p choice="Enter choice (1 or 2, default is 1): "
if "%choice%"=="" set choice=1

if "%choice%"=="1" (
    if exist "KaiserRadar.exe" (
        echo [*] Starting Kaiser Audio Radar...
        start "" "KaiserRadar.exe"
        exit /b 0
    ) else if exist "bin_win64\KaiserRadar.exe" (
        echo [*] Starting Kaiser Audio Radar...
        start "" "bin_win64\KaiserRadar.exe"
        exit /b 0
    ) else (
        echo [!] KaiserRadar.exe not found, starting Universal Engine...
        goto RUN_PYTHON
    )
)

:RUN_PYTHON
echo.
echo [*] Checking Python environment...
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo [*] Checking audio libraries (pyaudiowpatch, numpy)...
python -c "import pyaudiowpatch, numpy" >nul 2>nul
if errorlevel 1 (
    echo [*] Installing required audio libraries...
    python -m pip install -r universal-radar\requirements.txt
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed successfully!
)

echo [*] Starting Universal Radar...
cd universal-radar
python kaiser_audio_radar.py
if errorlevel 1 (
    echo.
    echo [!] Program exited with error.
    pause
)
